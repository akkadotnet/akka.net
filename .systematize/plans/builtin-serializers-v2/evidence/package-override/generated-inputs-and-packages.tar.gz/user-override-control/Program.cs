#nullable enable
using System.Runtime.CompilerServices;

if (RuntimeFeature.IsDynamicCodeSupported)
    throw new InvalidOperationException("[packaged-aot] Actual native execution is required.");
var found = AppContext.TryGetSwitch("Akka.DynamicTypeLoading", out var enabled);
if (!found || !enabled)
    throw new InvalidOperationException($"[packaged-aot] Late override must be explicit true: found={found}, value={enabled}.");
Console.WriteLine("[packaged-aot] late override OK found=true value=true");
